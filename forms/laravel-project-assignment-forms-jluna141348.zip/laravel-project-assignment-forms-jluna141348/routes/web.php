<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome');

Route::view('/about', 'about');

Route::view('/contact', 'contact');

Route::view('/services', 'services');

Route::view('/showcases', 'showcases');

Route::view('/blog', 'blog');

Route::get('/formtest', function () {
    $emails = session()->get('emails', []);

    return view('formtest', [
        'emails' => $emails,
    ]);
});

Route::post('/formtest', function () {
    request()->validate([
        'email' => 'required|email',
    ]);

    $emails = session()->get('emails', []);

    if (count($emails) >= 5) {
        return redirect('/formtest')->with('warning', 'Maximum of 5 emails reached.');
    }

    if (in_array(request('email'), $emails)) {
        return redirect('/formtest')->with('error', 'Email already added.');
    }

    session()->push('emails', request('email'));

    return redirect('/formtest')->with('success', 'Email added successfully.');
});

Route::post('/delete-email', function () {
    $emails = session()->get('emails', []);
    $index = request('index');

    if (isset($emails[$index])) {
        array_splice($emails, $index, 1);
        session()->put('emails', $emails);
    }

    return redirect('/formtest');
});

Route::get('/delete-emails', function () {
    session()->forget('emails');
    return redirect('/formtest');
});
