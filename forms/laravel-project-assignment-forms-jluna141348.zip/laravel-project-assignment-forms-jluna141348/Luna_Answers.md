# Luna_Answers.md

## Activity 2 Reflection Questions

### 1. What is the difference between GET and POST?

GET is used to request or retrieve data from the server. When you visit a page by typing a URL in the browser, that is a GET request. The data is visible in the URL. POST is used to send data to the server, like when you submit a form. The data is not visible in the URL and is sent inside the request body. In this activity, we use GET to load the formtest page and POST to submit the email.

### 2. Why do we use `@csrf` in forms?

`@csrf` generates a hidden token field in the form. Laravel checks this token when the form is submitted to make sure the request is coming from our own website and not from somewhere else. Without it, someone could trick a user into submitting a form from a different website, which is called a Cross-Site Request Forgery (CSRF) attack. Laravel will reject any POST request that does not have a valid CSRF token.

### 3. What is session used for in this activity?

Session is used to temporarily store the list of emails between page loads. Since HTTP is stateless (each request is separate), we need a way to remember data from one request to the next. In this activity, the emails are saved in the session after each form submission, so when the page reloads, we can still see the list of emails that were previously added.

### 4. What happens if session is cleared?

If the session is cleared, all the stored emails will be lost. The emails list will go back to being empty. This is what happens when you click the delete-all button or when the session expires. It shows that session storage is temporary and should not be used for data that needs to be saved permanently, like storing it in a database instead.
